package com.team18.simulator;

import java.util.Random;

public class WindModel {
	private double rangeMin = 1.0;
	private double rangeMax = 1.0;
	private double deviation;

	private Random r = new Random();

	public WindModel(double deviation) {
		this.deviation = deviation;
		rangeMax += deviation;
		rangeMin -= deviation;
	}

	public double getWindSpeed(double h) {
		if(h > 500_000)
			return 0;

		double randomFactor = rangeMin + (rangeMax - rangeMin) * r.nextDouble();

		return (0.0009975*h + 0.3)*randomFactor;
	}
}
