package com.team18.simulator;

import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.PerspectiveCamera;
import com.badlogic.gdx.graphics.VertexAttributes.Usage;
import com.badlogic.gdx.graphics.g3d.Environment;
import com.badlogic.gdx.graphics.g3d.Material;
import com.badlogic.gdx.graphics.g3d.Model;
import com.badlogic.gdx.graphics.g3d.ModelBatch;
import com.badlogic.gdx.graphics.g3d.ModelInstance;
import com.badlogic.gdx.graphics.g3d.attributes.ColorAttribute;
import com.badlogic.gdx.graphics.g3d.utils.ModelBuilder;
import com.badlogic.gdx.math.Vector3;

public class Rocket extends SpaceObject {

	private ModelBatch modelBatch;
	private Model model;
	private ModelInstance instance;

	// PID
	private double ddy = 0;
	private double dy = 0;
	private double ddx = 0;
	private double dx = 0;
	private double ddtheta = 0;
	private double dtheta = 0;

	private double V_i = 0; // Initial velocity
	private double Y_i = 0; // Initial height
	private double thrust = 0;
	private double sideThrust = 0;
	private double theta = 0;


	private final double G = -1.352;

	// Dimensions of the rocket in meters
	private final float WIDTH = 3f; // 15 meters
	private final float HEIGHT = 2f; // 10 meters
	private final static String COLOR = "00ffaa";
	private final static double MASS = 6000; //6000

	public Rocket(Planet planet, Vector3d position, Vector3d velocity) {
		super("Rocket", COLOR, MASS,
			new Vector3d(planet.getPosition(false).getX()+position.getX(), planet.getPosition(false).getY()+position.getY(), planet.getPosition(false).getZ()+position.getZ() ),
			new Vector3d(planet.getVelocity().getX()+velocity.getX(), planet.getVelocity().getY()+velocity.getY(), planet.getVelocity().getZ()+velocity.getZ() 
		));

		Y_i = velocity.getY() - planet.getRadius();

		// Create a new rocket model (a 3D cone to be exact)
		modelBatch = new ModelBatch();
		ModelBuilder modelBuilder = new ModelBuilder();
		model = modelBuilder.createCone(WIDTH, HEIGHT, WIDTH, 100, new Material(ColorAttribute.createDiffuse(Color.valueOf(COLOR))), Usage.Position | Usage.Normal);
		Vector3d pos = getPosition(true);
		instance = new ModelInstance(model, (int)pos.getX(), (int)pos.getY(), (int)pos.getZ());
	}

	// PID setters and getters
	public double get_ddy() { return ddy; }
	public double get_dy() { return dy; }
	public double get_y() { return getPosition(false).getY(); }
	
	public void set_ddy(double thrust) { ddy = G + (thrust / MASS) * Math.cos(theta); }
	public void set_dy() { dy += ddy; }
	public void set_y() { setPosition(getPosition(false).add(new Vector3d(0, dy, 0))); }

	public void set_ddx(double thrust) { ddx = (thrust / MASS) * Math.sin(theta); }
	public void set_dx() { dx += ddx; }
	public void set_x() { setPosition(getPosition(false).add(new Vector3d(dx, 0, 0))); }

	public void set_ddtheta(double thrust) { ddtheta = thrust; }
	public void set_dtheta() { dtheta += ddtheta; }
	public void set_theta() {
		System.out.println("ROTATION: " + dtheta);
		instance.transform.setToRotation(Vector3.Z, (float)dtheta);
		theta = dtheta;
	}

	public void setThrust(double thrust) { this.thrust = thrust; }
	public double getThrust() { return thrust; }
	public void setSideThrust(double thrust) { this.sideThrust = thrust; }
	public double getSideThrust() { return sideThrust; }
	public void setTheta(double theta) { this.theta = theta; }
	public double getTheta() { return theta; }

	@Override
	public void render(PerspectiveCamera cam, Environment environment) {		
		Vector3d x = getPosition(true);
		instance.transform.setTranslation((float)x.getX(), (float)x.getY(), (float)x.getZ());

		modelBatch.begin(cam);
		modelBatch.render(instance, environment);
		modelBatch.end();
	}

	@Override
	public void dispose() {
		modelBatch.dispose();
		model.dispose();
	}
	
}
