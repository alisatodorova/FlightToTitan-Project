package com.team18.simulator;

public class OnOff {
	private double target;
	private final double MAX_THRUST = 1;

	public OnOff(double target) {
		this.target = target;
	}

	public double compute(double theta, double pos) {
		System.out.println("THETA: " + theta);
		System.out.println("X: " + pos);
		double error = target - pos;
		
		if(theta >= 45)
			return -MAX_THRUST;
		else if(theta <= -45)
			return MAX_THRUST;

		if(error < 0)
			return -MAX_THRUST;
		else
			return MAX_THRUST;
	}
}
