package com.team18.simulator;

import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.PerspectiveCamera;
import com.badlogic.gdx.graphics.VertexAttributes.Usage;
import com.badlogic.gdx.graphics.g3d.Environment;
import com.badlogic.gdx.graphics.g3d.Material;
import com.badlogic.gdx.graphics.g3d.Model;
import com.badlogic.gdx.graphics.g3d.ModelBatch;
import com.badlogic.gdx.graphics.g3d.ModelInstance;
import com.badlogic.gdx.graphics.g3d.attributes.ColorAttribute;
import com.badlogic.gdx.graphics.g3d.utils.ModelBuilder;

public class Planet extends SpaceObject {
	private double radius;

	private ModelBatch modelBatch;
	private Model model;
	private ModelInstance instance;

	public Planet(String name, String color, double mass, double radius, Vector3d position, Vector3d velocity) {
		super(name, color, mass, position, velocity);
		this.radius = radius;
		
		// Divide data by some constants in order to create the 3D sphere later
		final float SCALED_RADIUS = (float)radius/(float)SIZE_SCALE;
		final float SCALED_POS_X = (float)(position.getX()/POSITION_SCALE);
		final float SCALED_POS_Y = (float)(position.getY()/POSITION_SCALE);
		final float SCALED_POS_Z = (float)(position.getZ()/POSITION_SCALE);

		// Create a new planet model (a 3D sphere to be exact)
		modelBatch = new ModelBatch();
		ModelBuilder modelBuilder = new ModelBuilder();
        model = modelBuilder.createSphere(SCALED_RADIUS*2, SCALED_RADIUS*2, SCALED_RADIUS*2, 20, 20, new Material(ColorAttribute.createDiffuse(Color.valueOf(color))), Usage.Position | Usage.Normal);
		instance = new ModelInstance(model, SCALED_POS_X, SCALED_POS_Y, SCALED_POS_Z);
	}

	public double getRadius() { return radius; }

	@Override
	public void render(PerspectiveCamera cam, Environment environment) {		
		Vector3d x = getPosition(true);
		instance.transform.setTranslation((float)x.getX(), (float)x.getY(), (float)x.getZ());

		modelBatch.begin(cam);
		modelBatch.render(instance, environment);
		modelBatch.end();
	}

	@Override
	public void dispose() {
		modelBatch.dispose();
		model.dispose();
	}
}
