package com.team18.simulator;

import java.util.ArrayList;

import com.badlogic.gdx.graphics.PerspectiveCamera;
import com.badlogic.gdx.graphics.g3d.Environment;
import com.badlogic.gdx.math.Vector;
import com.team18.simulator.solvers.EulerSolver;
import com.team18.simulator.solvers.RungeKuttaSolver;

public class SolarSystem {
	final double STEP_SIZE = 0;
	private double currentStep = 0;

	private ArrayList<SpaceObject> spaceObjects;

	private PerspectiveCamera cam;
	private Environment environment;

	private WindModel windModel = new WindModel(0.3);

	// PID
	final double ROCKET_STEP = 0.005;
	private Rocket rocket;
	private PID verticalController = new PID(0.1, 0, 600, 24000, 2575000);
	private OnOff horizontalController = new OnOff(100);

	public SolarSystem(PerspectiveCamera cam, Environment environment) {
		this.cam = cam;
		this.environment = environment;
		spaceObjects = new ArrayList<SpaceObject>();
	}

	public void addRocket(Rocket rocket) {
		add(rocket);
		this.rocket = rocket;
	}

	public void add(SpaceObject obj) {
		spaceObjects.add(obj);
	}

	public SpaceObject get(int ix) {
		return spaceObjects.get(ix);
	}

	public SpaceObject get(String name) {
		for(int i=0; i<spaceObjects.size(); i++) {
			if(name.equals(spaceObjects.get(i).getName()))
				return spaceObjects.get(i);
		}
		return null;
	}

	public int size() {
		return spaceObjects.size();
	}

	public void update() {
		Planet titan = (Planet)get("Titan");
		System.out.println(Math.abs(rocket.getPosition(false).getY() - titan.getRadius()));
		if( Math.abs(rocket.getPosition(false).getY() - titan.getRadius()) > 0.1 ) {
			updateRocket();
		} else {
			rocket.setPosition(new Vector3d(0, titan.getRadius(), 0));
		}

		for(int i=0; i<spaceObjects.size(); i++) {
			spaceObjects.get(i).render(cam, environment);
		}
	}

	final static double TITAN_G = 1.352;
	public void updateRocket() {
		double altitude = rocket.get_y() - get("Titan").getPosition(false).getY();

		if(altitude > 0) {
			double windSpeed = windModel.getWindSpeed(altitude);
			// Controllers
			double thrust = verticalController.compute(rocket.get_y());
			// THIS CONTROLLER NEEDS TUNING TO REACH THE TARGET !
			double sideThrust = horizontalController.compute(rocket.getTheta(), rocket.getPosition(false).getX());

			rocket.setThrust(thrust);
			rocket.setSideThrust(sideThrust);

			rocket.set_ddy(thrust);
			rocket.set_dy();
			rocket.set_y(); 

			rocket.set_ddx(thrust);
			rocket.set_dx();
			rocket.set_x(); 

			rocket.set_ddtheta(sideThrust);
			rocket.set_dtheta();
			rocket.set_theta();
		} else {
			altitude = 0;
		}
		
	}

	public double getAltitude() { return rocket.get_y() - get("Titan").getPosition(false).getY(); }
	public double getXPosition() { return rocket.getPosition(false).getX(); }
	public double getRotation() { return rocket.getTheta(); }
	public double getWindSpeed() { return windModel.getWindSpeed(getAltitude()); }
	public double getMainThrust() { return rocket.getThrust(); }
	public double getSideThrust() { return rocket.getSideThrust(); }
}
