package com.team18.simulator;

public class PID {
	private double kp;
	private double ki;
	private double kd;
	private double target;
	private double error = 0;
	private double integralError = 0;
	private double errorLast = 0;
	private double derivativeError = 0;
	private double output = 0;

	private double TIME_STEP = 1;
	private double MAX_THRUST;

	public PID(double kp, double ki, double kd, double maxThrust, double target) {
		this.kp = kp;
		this.ki = ki;
		this.kd = kd;
		this.target = target;
		this.MAX_THRUST = maxThrust;
	}

	public double compute(double pos) {
		error = target - pos;
		integralError += error * TIME_STEP;
		derivativeError = (error - errorLast) / TIME_STEP;
		errorLast = error;
		output = kp*error + ki*integralError + kd*derivativeError;

		if(output >= MAX_THRUST)
			output = MAX_THRUST;
		if(output <= 0)
			output = 0;

		return output;
	}
}
