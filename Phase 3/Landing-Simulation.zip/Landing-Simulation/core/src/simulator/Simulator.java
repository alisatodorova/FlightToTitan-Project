package com.team18.simulator;

import com.badlogic.gdx.ApplicationAdapter;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.PerspectiveCamera;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.g3d.Environment;
import com.badlogic.gdx.graphics.g3d.attributes.ColorAttribute;
import com.badlogic.gdx.graphics.g3d.environment.DirectionalLight;
import com.badlogic.gdx.graphics.g3d.utils.CameraInputController;
import com.badlogic.gdx.math.Vector3;

public class Simulator extends ApplicationAdapter {

	private PerspectiveCamera cam;
	private Environment environment;
	private CameraInputController camController;

	private SolarSystem solarSystem;

	private SpriteBatch batch;
    private BitmapFont font;

	@Override
	public void create () {
		// Create light
		environment = new Environment();
		environment.set(new ColorAttribute(ColorAttribute.AmbientLight, 0.4f, 0.4f, 0.4f, 1f));
		environment.add(new DirectionalLight().set(0.8f, 0.8f, 0.8f, -1f, -0.8f, -0.2f));

		// Create a perspective camera
		cam = new PerspectiveCamera(67, Gdx.graphics.getWidth(), Gdx.graphics.getHeight());
		cam.position.set(900, 0, 0);
		cam.lookAt(0, 0, 0);
		cam.near = 0.00001f;
		cam.far = 1000;
		

		// Make camera controllable
		camController = new CameraInputController(cam);
		camController.scrollFactor = 0.05f; // 0.5 best
        Gdx.input.setInputProcessor(camController);

		// UI Text
		batch = new SpriteBatch();    
        font = new BitmapFont();
        font.setColor(Color.RED);

		// Create SOLAR SYSTEM
		solarSystem = new SolarSystem(cam, environment);

		Planet titan = new Planet("Titan", "FFFFFF", 1.34553e23, 2575000,
			new Vector3d(0, 0, 0),
			new Vector3d(3.056877965721629e+03, 6.125612956428791e+03, -9.523587380845593e+02)
		);
		solarSystem.add(titan);

		// Add ROCKET
		Rocket rocket = new Rocket(titan, new Vector3d(0, 5000000, 0), new Vector3d(0, 0, 0));
		solarSystem.addRocket(rocket);
	}

	@Override
	public void render () {
		// Update camera controller
		camController.update();
		Gdx.gl.glViewport(0, 0, Gdx.graphics.getWidth(), Gdx.graphics.getHeight());
		Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT | GL20.GL_DEPTH_BUFFER_BIT);
		
		// Update space objects
		solarSystem.update();

		// Render UI Text
		batch.begin();
        font.draw(batch, "ALTITUDE: " + solarSystem.getAltitude() + " [m]", 100, 280);
		font.draw(batch, "ROTATION: " + solarSystem.getRotation() + " [deg]", 100, 260);
		font.draw(batch, "WIND SPEED: " + solarSystem.getWindSpeed() + " [m/s]", 100, 240);
		font.draw(batch, "MAIN THRUST: " + solarSystem.getMainThrust() + " [N]", 100, 220);
		font.draw(batch, "SIDE THRUST: " + solarSystem.getSideThrust() + " [N]", 100, 200);
        batch.end();

		KeyboardController.checkKeys(cam, camController, solarSystem);
		KeyboardController.checkLock(cam, camController, solarSystem);
	}
	
	@Override
	public void dispose () {

	}
}
