package com.team18.simulator;

import com.badlogic.gdx.graphics.PerspectiveCamera;
import com.badlogic.gdx.graphics.g3d.Environment;

public abstract class SpaceObject {
	//final double SCALE = 100_000;
	//final double POSITION_SCALE = 10e4;
	//final double SIZE_SCALE = 10e4;

	final double POSITION_SCALE = 10e3;
	final double SIZE_SCALE = 10e3;

	private String name;
	private String color;

	private double mass;
	private Vector3d position;
	private Vector3d velocity;

	public String getName() { return name; }
	public String getColor() { return color; }
	public double getMass() { return mass; }

	public SpaceObject(String name, String color, double mass, Vector3d position, Vector3d velocity) {
		this.name = name;
		this.color = color;
		this.mass = mass;
		this.position = new Vector3d(position.getX(), position.getY(), position.getZ());
		this.velocity = new Vector3d(velocity.getX(), velocity.getY(), velocity.getZ());
	}

	public void setPosition(Vector3d position) {
		this.position = new Vector3d(position.getX(), position.getY(), position.getZ());
	}

	public void setVelocity(Vector3d velocity) {
		this.velocity = new Vector3d(velocity.getX(), velocity.getY(), velocity.getZ());
	}

	public Vector3d getPosition(boolean normalize) {
		if(normalize)
			return new Vector3d((int)(position.getX()/POSITION_SCALE), (int)(position.getY()/POSITION_SCALE), (int)(position.getZ()/POSITION_SCALE));
		else
			return new Vector3d(position.getX(), position.getY(), position.getZ());
	}

	public Vector3d getVelocity() { 
		return new Vector3d(velocity.getX(), velocity.getY(), velocity.getZ());
	}

	public void render(PerspectiveCamera cam, Environment environment) {}
	public void dispose() {}
}
