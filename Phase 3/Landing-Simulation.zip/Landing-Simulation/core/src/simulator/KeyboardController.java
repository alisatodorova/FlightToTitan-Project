package com.team18.simulator;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input.Keys;
import com.badlogic.gdx.graphics.PerspectiveCamera;
import com.badlogic.gdx.graphics.g3d.utils.CameraInputController;
import com.badlogic.gdx.math.Vector3;

public class KeyboardController {

	private static int currentIx = 0;
	private static SpaceObject currentObject;
	private static final int ADD_DEFAULT_ROCKET = 20;
	private static final int ADD_DEFAULT_POSITION = 900;
	private static final int ADD_DEFAULT_POSITION_SUN = 20000;

	private static int toAdd = ADD_DEFAULT_POSITION;

	// Check if user clicked left or right arrow key to switch between space objects
	public static void checkKeys(PerspectiveCamera cam, CameraInputController camController, SolarSystem solarSystem) {
		if(Gdx.input.isKeyJustPressed(Keys.DPAD_LEFT)) {
			currentIx--;
			if(currentIx < 0)
				currentIx = solarSystem.size()-1;
			currentObject = solarSystem.get(currentIx);

			if(currentObject.getName().equals("Rocket"))
				toAdd = ADD_DEFAULT_ROCKET;
			else if(currentObject.getName().equals("Sun"))
				toAdd = ADD_DEFAULT_POSITION_SUN;
			else
				toAdd = ADD_DEFAULT_POSITION;
			
			// Set the camera
			Vector3d pos = currentObject.getPosition(true);
			cam.position.set((float)pos.getX()+toAdd, (float)pos.getY(), (float)pos.getZ());
			cam.lookAt((float)pos.getX(), (float)pos.getY(), (float)pos.getZ());
			camController.target = new Vector3((int)pos.getX(), (int)pos.getY(), (int)pos.getZ());
			cam.update();
		} else if(Gdx.input.isKeyJustPressed(Keys.DPAD_RIGHT)) {
			currentIx++;
			if(currentIx > solarSystem.size()-1)
				currentIx = 0;
			currentObject = solarSystem.get(currentIx);

			if(currentObject.getName().equals("Rocket"))
				toAdd = ADD_DEFAULT_ROCKET;
			else if(currentObject.getName().equals("Sun"))
				toAdd = ADD_DEFAULT_POSITION_SUN;
			else
				toAdd = ADD_DEFAULT_POSITION;
			
			// Set the camera
			Vector3d pos = currentObject.getPosition(true);
			cam.position.set((float)pos.getX()+toAdd, (float)pos.getY(), (float)pos.getZ());
			cam.lookAt((float)pos.getX(), (float)pos.getY(), (float)pos.getZ());
			camController.target = new Vector3((int)pos.getX(), (int)pos.getY(), (int)pos.getZ());
			cam.update();
		}
	}

	public static void checkLock(PerspectiveCamera cam, CameraInputController camController, SolarSystem solarSystem) {
		if(Gdx.input.isKeyPressed(Keys.SPACE)) {
			// Set the camera
			Vector3d pos = solarSystem.get(currentIx).getPosition(true);
			cam.position.set((float)pos.getX()+toAdd, (float)pos.getY(), (float)pos.getZ());
			cam.lookAt((float)pos.getX(), (float)pos.getY(), (float)pos.getZ());
			camController.target = new Vector3((int)pos.getX(), (int)pos.getY(), (int)pos.getZ());
			cam.update();
		}
	}

	public static SpaceObject getSelectedObject() {
		return currentObject;
	}

	public static int getSelectedObjectIndex() {
		return currentIx;
	}
}
